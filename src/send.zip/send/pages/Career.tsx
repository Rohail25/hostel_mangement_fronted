import Header from '../components/Header'
import Footer from '../components/Footer'

const Career = () => {
    return (
        <div className="min-h-screen bg-white flex flex-col">
            <Header />
            <main className="container mx-auto px-6 py-16 flex-1">
                <h1 className="text-4xl font-bold text-gray-900 mb-4">Career</h1>
                <p className="text-gray-600">We’re hiring across teams. Job listings will appear here.</p>
            </main>
            <Footer />
        </div>
    )
}

export default Career


